import java.util.ArrayList;
import java.util.List;

public class MainPizzeria {
    public static void main(String[] args) {
        List<Pedido> pedidos = new ArrayList<>();

        // Crear diferentes tipos de pedidos
        String[] ingredientesPizza = {"Queso Extra", "Pepperoni", "Champiñones"};
        pedidos.add(new PedidoPizza("Juan Pérez", "Calle 123", 12.99, true, "Grande", ingredientesPizza));

        pedidos.add(new PedidoHamburguesa("María García", "Avenida 456", 8.99, false, true, 3));

        // Procesamiento polimórfico
        for (Pedido p : pedidos) {
            System.out.println("\n" + "=".repeat(50));
            p.mostrarDetallesEspeciales();
            p.mostrarResumenPedido();
            System.out.println("Total: $" + String.format("%.2f", p.calcularCostoTotal()));
            System.out.println("Tiempo estimado: " + p.estimarTiempoEntrega() + " min");
            System.out.println("=".repeat(50));
        }
    }
}