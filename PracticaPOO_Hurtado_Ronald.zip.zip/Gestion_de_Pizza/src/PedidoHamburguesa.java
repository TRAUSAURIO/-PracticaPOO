public class PedidoHamburguesa extends Pedido {
    private boolean comboCompleto;
    private int nivelPicante;
    private final double COSTO_DELIVERY = 2.80;
    private final int TIEMPO_BASE = 15;
    private final int TIEMPO_DELIVERY = 10;

    public PedidoHamburguesa(String cliente, String direccion, double precioBase, boolean delivery,
                             boolean comboCompleto, int nivelPicante) {
        super(cliente, direccion, precioBase, TipoComida.HAMBURGUESA, delivery);
        this.comboCompleto = comboCompleto;
        this.nivelPicante = nivelPicante;
    }

    @Override
    public double calcularCostoTotal() {
        double total = getPrecioBase();
        if (isDelivery()) {
            total += COSTO_DELIVERY;
        }
        return total;
    }

    @Override
    public void mostrarResumenPedido() {
        System.out.println("=== PEDIDO DE HAMBURGUESA ===");
        System.out.println("Cliente: " + getCliente());
        System.out.println("Dirección: " + getDireccion());
        System.out.println("Precio base: $" + getPrecioBase());
        System.out.println("Combo completo: " + (comboCompleto ? "Sí" : "No"));
        System.out.println("Nivel de picante: " + nivelPicante + "/5");
        System.out.println("Delivery: " + (isDelivery() ? "Sí (+$" + COSTO_DELIVERY + ")" : "No"));
    }

    @Override
    public int estimarTiempoEntrega() {
        int tiempo = TIEMPO_BASE;
        if (isDelivery()) {
            tiempo += TIEMPO_DELIVERY;
        }
        return tiempo;
    }

    @Override
    public void mostrarDetallesEspeciales() {
        System.out.println("Detalles especiales de Hamburguesa:");
        System.out.println("- Combo completo: " + comboCompleto);
        System.out.println("- Nivel de picante: " + nivelPicante);
    }

    // Getters y Setters adicionales
    public boolean isComboCompleto() { return comboCompleto; }
    public void setComboCompleto(boolean comboCompleto) { this.comboCompleto = comboCompleto; }

    public int getNivelPicante() { return nivelPicante; }
    public void setNivelPicante(int nivelPicante) { this.nivelPicante = nivelPicante; }
}