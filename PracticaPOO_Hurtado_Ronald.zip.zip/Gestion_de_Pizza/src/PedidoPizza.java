public class PedidoPizza extends Pedido {
    private String tamanio;
    private String[] ingredientesExtra;
    private final double COSTO_DELIVERY = 3.50;
    private final int TIEMPO_BASE = 25;
    private final int TIEMPO_DELIVERY = 10;

    public PedidoPizza(String cliente, String direccion, double precioBase, boolean delivery,
                       String tamanio, String[] ingredientesExtra) {
        super(cliente, direccion, precioBase, TipoComida.PIZZA, delivery);
        this.tamanio = tamanio;
        this.ingredientesExtra = ingredientesExtra;
    }

    @Override
    public double calcularCostoTotal() {
        double total = getPrecioBase();
        if (isDelivery()) {
            total += COSTO_DELIVERY;
        }
        return total;
    }

    @Override
    public void mostrarResumenPedido() {
        System.out.println("=== PEDIDO DE PIZZA ===");
        System.out.println("Cliente: " + getCliente());
        System.out.println("Dirección: " + getDireccion());
        System.out.println("Tamaño: " + tamanio);
        System.out.println("Precio base: $" + getPrecioBase());
        System.out.println("Delivery: " + (isDelivery() ? "Sí (+$" + COSTO_DELIVERY + ")" : "No"));
        System.out.println("Ingredientes extra: " + String.join(", ", ingredientesExtra));
    }

    @Override
    public int estimarTiempoEntrega() {
        int tiempo = TIEMPO_BASE;
        if (isDelivery()) {
            tiempo += TIEMPO_DELIVERY;
        }
        return tiempo;
    }

    @Override
    public void mostrarDetallesEspeciales() {
        System.out.println("Detalles especiales de Pizza:");
        System.out.println("- Tamaño: " + tamanio);
        System.out.println("- Número de ingredientes extra: " + ingredientesExtra.length);
    }

    // Getters y Setters adicionales
    public String getTamanio() { return tamanio; }
    public void setTamanio(String tamanio) { this.tamanio = tamanio; }

    public String[] getIngredientesExtra() { return ingredientesExtra; }
    public void setIngredientesExtra(String[] ingredientesExtra) { this.ingredientesExtra = ingredientesExtra; }
}