
    public enum TipoComida {
        PIZZA,
        HAMBURGUESA,
        SUSHI,
        ENSALADA,
        POSTRE,
        BEBIDA
    }

